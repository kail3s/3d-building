import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {ThreeCanvas} from "@remotion/three";

const Knot: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame, fps, config: {damping: 12, stiffness: 80}});
  return (
    <mesh rotation={[frame * 0.02, frame * 0.03, 0]} scale={s * 1.3}>
      <torusKnotGeometry args={[1, 0.34, 256, 32]} />
      <meshStandardMaterial color="#7c5cff" metalness={0.7} roughness={0.25} />
    </mesh>
  );
};

const Orbiters: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const count = 14;
  return (
    <>
      {Array.from({length: count}).map((_, i) => {
        const delay = 20 + i * 3;
        const pop = spring({frame: frame - delay, fps, config: {damping: 10}});
        const a = (i / count) * Math.PI * 2 + frame * 0.025;
        const r = 3.4;
        const y = Math.sin(frame * 0.06 + i) * 0.8;
        return (
          <mesh key={i} position={[Math.cos(a) * r, y, Math.sin(a) * r]} scale={pop * 0.22}>
            <icosahedronGeometry args={[1, 1]} />
            <meshStandardMaterial
              color={`hsl(${(i * 25 + frame * 2) % 360}, 90%, 60%)`}
              metalness={0.4}
              roughness={0.3}
            />
          </mesh>
        );
      })}
    </>
  );
};

export const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height, durationInFrames} = useVideoConfig();

  const camZ = interpolate(frame, [0, durationInFrames], [10, 6.5]);
  const groupRotY = frame * 0.008;
  const titleIn = spring({frame: frame - 25, fps, config: {damping: 14}});
  const fadeOut = interpolate(frame, [durationInFrames - 20, durationInFrames], [1, 0], {
    extrapolateLeft: "clamp",
  });

  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(circle at 50% 40%, #1b1442 0%, #07060f 70%)",
        opacity: fadeOut,
      }}
    >
      <ThreeCanvas
        width={width}
        height={height}
        camera={{position: [0, 1.5, camZ], fov: 50}}
      >
        <ambientLight intensity={0.6} />
        <pointLight position={[8, 8, 8]} intensity={120} color="#ffffff" />
        <pointLight position={[-8, -4, 4]} intensity={80} color="#ff4fa3" />
        <group rotation={[0, groupRotY, 0]}>
          <Knot />
          <Orbiters />
        </group>
      </ThreeCanvas>

      <AbsoluteFill
        style={{
          justifyContent: "flex-end",
          alignItems: "center",
          paddingBottom: 110,
          fontFamily: "Helvetica, Arial, sans-serif",
          color: "white",
        }}
      >
        <div
          style={{
            fontSize: 110,
            fontWeight: 800,
            letterSpacing: 6,
            opacity: titleIn,
            transform: `translateY(${(1 - titleIn) * 60}px)`,
          }}
        >
          MOTION 3D
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
