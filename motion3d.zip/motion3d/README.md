# motion3d (Remotion + React Three Fiber)

npm install
npm run dev     # live preview in Remotion Studio
npm run build   # renders out/video.mp4 (1920x1080, 30fps, 10s)

Edit src/Scene.tsx to change the 3D scene. Node 18+ required.
